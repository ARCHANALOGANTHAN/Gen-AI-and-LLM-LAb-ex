# Gradio Generative AI Text Summarizer

## Overview
This project is a Generative AI text summarization application built with Gradio.

Users can enter text through a web interface, and the application generates a concise summary using the BART summarization model.

## Model
`facebook/bart-large-cnn`

## Features
- Interactive Gradio interface
- Text summarization
- Input validation
- Transformer-based summarization
- ROUGE evaluation example

## Workflow
1. Load the BART tokenizer and model.
2. Accept text through the Gradio interface.
3. Tokenize the input with truncation.
4. Generate a summary using beam search.
5. Display the generated summary.
6. Calculate ROUGE scores for a sample prediction/reference pair.

## Generation Settings
- Maximum input length: 1024 tokens
- Maximum new tokens: 45
- Minimum new tokens: 15
- Beam search: 4 beams
- Sampling: disabled

## Requirements
```bash
pip install gradio transformers torch evaluate
```

## Run
```bash
python "gen ai 12.py"
```

## Interface
The application provides:
- **Input:** Textbox for text to summarize
- **Output:** Generated summary textbox

## Evaluation
The script uses the `evaluate` library and ROUGE metric for a sample generated summary and reference summary.

## Technologies
Python, Gradio, PyTorch, Hugging Face Transformers, BART, ROUGE
