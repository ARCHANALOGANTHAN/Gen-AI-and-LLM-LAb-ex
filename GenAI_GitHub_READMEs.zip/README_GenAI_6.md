# Retrieval-Augmented Generation (RAG) with FAISS

## Overview
This project demonstrates a basic Retrieval-Augmented Generation pipeline.

The system stores a small knowledge base, converts documents into embeddings, retrieves relevant documents using FAISS, and uses the retrieved context to generate an answer.

## Objective
Understand the basic workflow of RAG.

## Workflow
1. Create a small knowledge base.
2. Generate document embeddings using `all-MiniLM-L6-v2`.
3. Build a FAISS vector index.
4. Convert the user query into an embedding.
5. Retrieve the top-2 relevant documents.
6. Build an augmented prompt.
7. Generate an answer using FLAN-T5.

## Models and Tools
- Sentence Transformers: `all-MiniLM-L6-v2`
- Vector search: FAISS
- Text generation: `google/flan-t5-base`

## Example Query
`What is RAG in AI?`

## Requirements
```bash
pip install sentence-transformers faiss-cpu transformers torch numpy
```

## Run
```bash
python "gen ai 6.py"
```

## Technologies
Python, FAISS, Sentence Transformers, Hugging Face Transformers, FLAN-T5
