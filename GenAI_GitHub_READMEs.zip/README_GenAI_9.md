# Image Captioning and Visual Question Answering

## Overview
This project demonstrates two vision-language tasks using BLIP:
- Image captioning
- Visual Question Answering (VQA)

## Objective
Use a pre-trained vision-language model to understand an image and generate text about it.

## Workflow
1. Download an image from a URL.
2. Convert it into RGB format.
3. Generate a caption using BLIP image captioning.
4. Ask a question about the image.
5. Generate an answer using BLIP VQA.

## Models
- `Salesforce/blip-image-captioning-base`
- `Salesforce/blip-vqa-base`

## Example Question
`What animal is in the picture?`

## Requirements
```bash
pip install transformers torch pillow requests
```

## Run
```bash
python "gen ai 9.py"
```

## Output
The program displays:
- Generated image caption
- Question
- Answer

## Technologies
Python, PyTorch, BLIP, Hugging Face Transformers, PIL
