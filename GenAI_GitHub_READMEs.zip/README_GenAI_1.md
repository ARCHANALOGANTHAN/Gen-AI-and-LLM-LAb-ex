# GenAI Text Generation with GPT-2

## Overview
This project demonstrates basic text generation using the pre-trained GPT-2 model from Hugging Face Transformers.

## Objective
Generate multiple text continuations from a given prompt using sampling techniques.

## Model
- GPT-2
- Hugging Face Transformers

## Features
- Uses a pre-trained GPT-2 model
- Reproducible generation using a fixed seed
- Generates two text outputs
- Uses temperature, top-k, and top-p sampling

## Input
Prompt: `Artificial Intelligence will transform the future of`

## Parameters
- `max_length=60`
- `num_return_sequences=2`
- `temperature=0.8`
- `top_k=50`
- `top_p=0.95`

## Requirements
```bash
pip install transformers torch
```

## Run
```bash
python "gen ai 1.py"
```

## Output
The program displays two generated text continuations.

## Technologies
Python, PyTorch, Hugging Face Transformers, GPT-2
