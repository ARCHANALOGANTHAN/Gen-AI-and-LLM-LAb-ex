# Text Summarization and Question Answering

## Overview
This project demonstrates two Natural Language Processing tasks:
- Text summarization
- Question answering

## Models
### Summarization
`facebook/bart-large-cnn`

### Question Answering
`distilbert-base-cased-distilled-squad`

## Objective
Summarize an article and answer a question using the original article as context.

## Features
- Transformer-based summarization
- Extractive question answering
- Confidence score for the answer

## Workflow
1. Load the BART tokenizer and model.
2. Tokenize the article.
3. Generate a summary.
4. Load the question-answering pipeline.
5. Ask a question using the article as context.
6. Display the answer and confidence.

## Requirements
```bash
pip install transformers torch
```

## Run
```bash
python "gen ai 4.py"
```

## Technologies
Python, PyTorch, Hugging Face Transformers, BART, DistilBERT
