# Prompt Engineering with GPT-2

## Overview
This project compares three prompt engineering approaches using the GPT-2 text-generation model.

## Techniques Demonstrated
1. Zero-shot prompting
2. Few-shot prompting
3. Chain-of-Thought style prompting

## Objective
Understand how different prompt structures influence the generated response.

## Examples
- Zero-shot: classify a review as Positive or Negative.
- Few-shot: provide examples before asking for a new classification.
- Chain-of-Thought style: provide a worked arithmetic example before a new question.

## Model
`gpt2`

## Requirements
```bash
pip install transformers torch
```

## Run
```bash
python "gen ai 2.py"
```

## Output
The program prints the generated response for each prompting technique.

## Technologies
Python, PyTorch, Hugging Face Transformers, GPT-2
