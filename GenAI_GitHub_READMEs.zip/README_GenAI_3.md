# Conversational AI Chatbot with DialoGPT

## Overview
This project implements a simple command-line conversational chatbot using Microsoft's DialoGPT-medium model.

## Objective
Generate conversational responses while maintaining conversation history during the session.

## Features
- Interactive command-line chat
- Conversation history
- Pre-trained DialoGPT model
- Sampling with top-k and top-p

## Model
`microsoft/DialoGPT-medium`

## How It Works
1. Load the tokenizer and model.
2. Accept user input.
3. Encode the input.
4. Append it to previous conversation history.
5. Generate a response.
6. Decode and display the new response.

## Exit
Type:
```text
quit
```

## Requirements
```bash
pip install transformers torch
```

## Run
```bash
python "gen ai 3.py"
```

## Technologies
Python, PyTorch, Hugging Face Transformers, DialoGPT
