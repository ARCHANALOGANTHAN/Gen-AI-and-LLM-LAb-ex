# Fine-Tuning DistilBERT for IMDB Sentiment Classification

## Overview
This project fine-tunes the pre-trained DistilBERT model on a smaller subset of the IMDB movie review dataset.

## Objective
Demonstrate the workflow for dataset loading, tokenization, model fine-tuning, evaluation, and model saving.

## Dataset
`imdb`

The script uses:
- 2,000 training samples
- 500 testing samples

## Model
`distilbert-base-uncased`

## Workflow
1. Load the IMDB dataset.
2. Select smaller training and testing subsets.
3. Tokenize text with DistilBERT tokenizer.
4. Load a sequence classification model with two labels.
5. Train for 2 epochs.
6. Evaluate using accuracy.
7. Save the fine-tuned model and tokenizer.

## Training Configuration
- Epochs: 2
- Training batch size: 8
- Evaluation batch size: 8
- Maximum sequence length: 128

## Output Directory
`./fine_tuned_distilbert_imdb`

## Requirements
```bash
pip install datasets transformers torch numpy scikit-learn
```

## Run
```bash
python "gen ai 10.py"
```

## Technologies
Python, PyTorch, Hugging Face Transformers, Datasets, DistilBERT, scikit-learn
