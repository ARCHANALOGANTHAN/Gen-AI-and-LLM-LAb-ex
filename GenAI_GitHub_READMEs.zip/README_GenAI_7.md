# AI Code Generation and Debugging

## Overview
This project demonstrates code generation and debugging assistance using the Salesforce CodeGen model.

## Objective
Generate programming code from natural-language prompts and use the model to suggest a correction for faulty code.

## Model
`Salesforce/codegen-350M-mono`

## Features
- Natural-language to code generation
- Code debugging assistance
- Python code examples

## Demonstrations
### Code Generation
The prompt asks the model to generate a Python function for checking whether a number is prime.

### Debugging
A faulty factorial function is provided, and the model is prompted to generate a corrected version.

## Requirements
```bash
pip install transformers torch
```

## Run
```bash
python "gen ai 7.py"
```

## Technologies
Python, PyTorch, Hugging Face Transformers, CodeGen
