# Sentiment Analysis and Zero-Shot Classification

## Overview
This project demonstrates sentiment analysis and zero-shot document classification using Hugging Face Transformers.

## Tasks
### Sentiment Analysis
Analyzes two sample product reviews and predicts their sentiment with a confidence score.

### Zero-Shot Classification
Classifies a document into candidate categories without task-specific training.

## Model
- Sentiment Analysis: default Transformers sentiment pipeline model
- Zero-shot classification: `facebook/bart-large-mnli`

## Candidate Labels
- Politics
- Economy
- Sports
- Technology

## Objective
Show how pre-trained language models can perform NLP classification tasks with minimal code.

## Requirements
```bash
pip install transformers torch
```

## Run
```bash
python "gen ai 5.py"
```

## Output
The program prints sentiment labels, scores, and zero-shot classification scores.

## Technologies
Python, PyTorch, Hugging Face Transformers
