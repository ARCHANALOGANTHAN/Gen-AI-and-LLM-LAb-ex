# Multi-Modal Content Generation

## Overview
This project demonstrates a simple Generative AI pipeline that creates:
- Text
- Image
- Audio

from a single topic.

## Topic
`The benefits of renewable energy`

## Workflow
### 1. Text Generation
Uses `google/flan-t5-base` to generate a short paragraph about the topic.

### 2. Image Generation
Uses Stable Diffusion to generate an illustration related to the topic.

### 3. Text-to-Speech
Uses gTTS to convert the generated text into English speech.

## Models and Libraries
- FLAN-T5
- Stable Diffusion v1.5
- gTTS
- PyTorch

## Output Files
- `content_image.png`
- `content_audio.mp3`

## Hardware
The script automatically checks for CUDA and uses GPU when available; otherwise it uses CPU.

## Requirements
```bash
pip install transformers diffusers torch gtts accelerate
```

## Run
```bash
python "gen ai 11.py"
```

## Technologies
Python, PyTorch, Hugging Face Transformers, Diffusers, Stable Diffusion, gTTS
