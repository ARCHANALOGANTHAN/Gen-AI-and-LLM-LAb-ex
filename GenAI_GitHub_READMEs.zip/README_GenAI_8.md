# Stable Diffusion Image Generation

## Overview
This project generates an image from a text prompt using Stable Diffusion.

## Objective
Demonstrate text-to-image generation with a pre-trained diffusion model.

## Model
`runwayml/stable-diffusion-v1-5`

## Prompt
`A futuristic city skyline at sunset, digital art, highly detailed`

## Features
- Text-to-image generation
- Automatic GPU/CPU selection
- Image saved as a PNG file

## Hardware
The program checks whether CUDA is available:
- NVIDIA GPU: uses CUDA with FP16
- Otherwise: runs on CPU

## Requirements
```bash
pip install diffusers torch transformers accelerate
```

## Run
```bash
python "gen ai 8.py"
```

## Output
Generated image:
`generated_city.png`

## Technologies
Python, PyTorch, Diffusers, Stable Diffusion
